library(gllvm)
library(vegan)
library("FactoMineR")
library("factoextra")
library(fBasics)#take trace
library(combinat)#permutation
library("readxl")
library(gtools)

one_branch = read.csv("one branch.csv")
two_branches = read.csv("two branches.csv")
three_branches_red = read.csv("three branches red.csv")
three_lobes_green = read.csv("three lobes green.csv")
three_lobes_purple= read.csv("three lobes purple.csv")
three_lobes_purple_try = read.csv("three lobes purple try.csv")
one_lobe_samll = read.csv("one lobe samll.csv")
#one_branch_new = read.csv("one branch 11 12 cahnged.csv")
one_lobe_samll_new = read.csv("one lobe samll 11 12 changed.csv")


one_branch = as.matrix(one_branch)
two_branches = as.matrix(two_branches)
three_branches_red = as.matrix(three_branches_red)
three_lobes_green = as.matrix(three_lobes_green)
three_lobes_purple = as.matrix(three_lobes_purple)
three_lobes_purple_try = as.matrix(three_lobes_purple_try)
one_lobe_samll = as.matrix(one_lobe_samll)
#one_branch_new = as.matrix(one_branch_new)
one_lobe_samll_new = as.matrix(one_lobe_samll_new)
source("resistant_codes_LMS_LTS.txt")


P_mat = two_branches
Q_mat = three_branches_red

result_MM2= MM2_estimator_with_reflection(Q_mat,P_mat)
MM2_obj = result_MM2$s
res_MM2 = MM2_permute(P_mat,Q_mat,999,MM2_obj)
res_MM2$p_value
vector_1 = rep(1,dim(P_mat)[1])

result_MM2_residual = 
  Q_mat - result_MM2$scal*(P_mat)%*%(result_MM2$rot)-vector_1%*%t(c(result_MM2$trans_1,result_MM2$trans_2))
result_MM2_residual_dis =  sqrt(rowSums(result_MM2_residual*result_MM2_residual))
barplot(result_MM2_residual_dis,
        las = 1,main="MM2",cex.names = 0.65,names.arg = 1:18)

MM2_trans_P = result_MM2$scal * (P_mat) %*% (result_MM2$rot) + vector_1 %*% t(c(result_MM2$trans_1, result_MM2$trans_2))


##
result_Huber= majorization_tuned(P_mat,Q_mat,1)
Huber_obj = result_Huber$s
res_Huber = Huber_permute(P_mat,Q_mat,999,Huber_obj)
sum(res_Huber$converge_vec)
diag(result_Huber$weight)
res_Huber$p_value

result_Huber_residual = 
  Q_mat - result_Huber$scal*(P_mat)%*%(result_Huber$rot)-vector_1%*%t(result_Huber$trans_P)
result_Huber_residual_dis =  sqrt(rowSums(result_Huber_residual*result_Huber_residual))
barplot(result_Huber_residual_dis,las = 1,
        main="Huber",cex.names = 0.65,names.arg = 1:18)



#######
result_Biweight= majorization_tuned(P_mat,Q_mat,2)
Biweight_obj = result_Biweight$s
res_bi = Biweight_permute(P_mat,Q_mat,999,Biweight_obj)
sum(res_bi$converge_vec)
res_bi$p_value
diag(result_Biweight$weight)
sort(diag(result_Biweight$weight))
vector_1 = rep(1,dim(P_mat)[1])

result_Biweight_residual = 
  Q_mat - result_Biweight$scal*(P_mat)%*%(result_Biweight$rot)-vector_1%*%t(result_Biweight$trans_P)
result_Biweight_residual_dis =  sqrt(rowSums(result_Biweight_residual*result_Biweight_residual))
barplot(result_Biweight_residual_dis,
        las = 1,main="Biweight",cex.names = 0.65,names.arg = 1:18)



##procrustes##
#vector_1 = rep(1,dim(P_mat)[1])
result_proc = Procrustes_fun(P_mat,Q_mat)
procrustes_obj = result_proc$s
res_procrustes = Procrustes_permute(P_mat,Q_mat,999,procrustes_obj)
sum(res_procrustes$converge_vec)
res_procrustes$p_value

result_procrustes_residual = 
  Q_mat - result_proc$scal*(P_mat)%*%(result_proc$rot)-vector_1%*%t(result_proc$trans_P)
procrustes_residual_dis = sqrt(rowSums(result_procrustes_residual*result_procrustes_residual))
barplot(procrustes_residual_dis,las = 1,
        main="Procrustes",cex.names = 0.65,names.arg = 1:18)

procrustes_trans_P = result_proc$scal*(P_mat)%*%(result_proc$rot)+vector_1%*%t(result_proc$trans_P)

############
result_S= S_estimator(P_mat,Q_mat,c_value,A_value,0,s_l,s_u)  
S_obj = result_S$s
res_S = S_permute(P_mat,Q_mat,999,S_obj)

result_S_residual = 
  Q_mat - result_S$scal*(P_mat)%*%(result_S$rot)-vector_1%*%t(result_S$trans_P)
result_S_residual_dis = sqrt(rowSums(result_S_residual*result_S_residual))
barplot(result_S_residual_dis,las = 1,
        main="S",cex.names = 0.65,names.arg = 1:18)



#########
result_LMS= LMS_estimator(P_mat,Q_mat,0,s_l_LMS,s_u_LMS)
LMS_obj = result_LMS$s
LMS_permute(P_mat,Q_mat,999,LMS_obj)

result_LMS_residual = 
  Q_mat - result_LMS$scal*(P_mat)%*%(result_LMS$rot)-vector_1%*%t(result_LMS$trans_P)
result_LMS_residual_dis = sqrt(rowSums(result_LMS_residual*result_LMS_residual))
barplot(result_LMS_residual_dis,las = 1,
        main="LMS",cex.names = 0.65,names.arg = 1:18)


###########
result_LTS= LTS_estimator(P_mat,Q_mat,0)
LTS_obj = result_LTS$s
res_LTS = LTS_permute(P_mat,Q_mat,999,LTS_obj)
sum(res_LTS$converge_vec)
res_LTS$p_value
 
result_LTS_residual = 
  Q_mat - result_LTS$scal*(P_mat)%*%(result_LTS$rot)-vector_1%*%t(result_LTS$trans_P)
result_LTS_residual_dis = sqrt(rowSums(result_LTS_residual*result_LTS_residual))
barplot(result_LTS_residual_dis,las = 1,
        main="LTS",cex.names = 0.65,names.arg = 1:18)


#############################ILMS (improved LMS)
result_ILMS= LMS_LTS_estimator(P_mat,Q_mat,0,s_l_LMS,s_u_LMS)
ILMS_obj = result_ILMS$s
res_ILMS = ILMS_permute(P_mat,Q_mat,999,ILMS_obj)
sum(res_ILMS$converge_vec)
res_ILMS$p_value

result_ILMS_residual = 
  Q_mat - result_ILMS$scal*(P_mat)%*%(result_ILMS$rot)-vector_1%*%t(result_ILMS$trans_P)
result_ILMS_residual_dis = sqrt(rowSums(result_ILMS_residual*result_ILMS_residual))
barplot(result_ILMS_residual_dis,las = 1,
        main="ILMS",cex.names = 0.65,names.arg = 1:18)

ILMS_trans_P = result_ILMS$scal*(P_mat)%*%(result_ILMS$rot)+vector_1%*%t(result_ILMS$trans_P)



#########
par(mfrow=c(2,2),mar=c(3.5,1,1,1),oma=c(2,3,1.5,0),cex.axis = 1,las=2)
outer = FALSE
line = -0.5
cex = 1.5
adj  = 0.02
barplot(result_Huber_residual_dis,
        main = " ",
        xlab = " ",
        ylab = " ",
        #xaxt = "n",
        names.arg = 1:19,
        col = "darkgray",
        horiz = FALSE)
title(outer=outer,adj=adj,main="Huber",cex.main=cex,col="black",font=2,line=line)
barplot(result_Biweight_residual_dis,
        main = " ",
        xlab = " ",
        ylab = " ",
        #xaxt = "n",
        names.arg = 1:18,
        col = "darkgray",
        horiz = FALSE)
title(outer=outer,adj=adj,main="Biweight",cex.main=cex,col="black",font=2,line=line)
barplot(result_S_residual_dis,
        main = " ",
        xlab = " ",
        ylab = " ",
        #xaxt = "n",
        names.arg = 1:18,
        col = "darkgray",
        horiz = FALSE)
title(outer=outer,adj=adj,main="S",cex.main=cex,col="black",font=2,line=line)
barplot(result_LMS_residual_dis,
        main = " ",
        xlab = " ",
        ylab = " ",
        xaxt = "n",
        #names.arg = 1:15,
        col = "darkgray",
        horiz = FALSE)
title(outer=outer,adj=adj,main="LMS",cex.main=cex,col="black",font=2,line=line)
barplot(result_LTS_residual_dis,
        main = " ",
        xlab = " ",
        ylab = " ",
        #xaxt = "n",
        names.arg = 1:18,
        col = "darkgray",
        horiz = FALSE)
title(outer=outer,adj=adj,main="LTS",cex.main=cex,col="black",font=2,line=line)
barplot(procrustes_residual_dis,
        main = " ",
        xlab = " ",
        ylab = " ",
        names.arg = 1:18,
        col = "darkgray",
        horiz = FALSE)
title(outer=outer,adj=adj,main="Procrustes",cex.main=cex,col="black",font=2,line=line)
barplot(result_MM2_residual_dis,
        main = " ",
        xlab = " ",
        ylab = " ",
        names.arg = 1:18,
        col = "darkgray",
        horiz = FALSE)
title(outer=outer,adj=adj,main="MM2",cex.main=cex,col="black",font=2,line=line)




#########
par(mfrow=c(2,4),mar=c(4,4,1,1),oma=c(2,1,1.5,0),cex.axis = 1.5,las=3)
outer = FALSE
line = -0.5
cex = 1.5
adj  = 0.02
plot(procrustes_residual_dis,result_Biweight_residual_dis,cex.lab=cex)
abline(lm(result_Biweight_residual_dis ~ procrustes_residual_dis), col = "red")

plot(procrustes_residual_dis,result_LTS_residual_dis,cex.lab=cex)
abline(lm(result_LTS_residual_dis ~ procrustes_residual_dis), col = "red")

plot(procrustes_residual_dis,result_S_residual_dis,cex.lab=cex)
abline(lm(result_S_residual_dis ~ procrustes_residual_dis), col = "red")

plot(result_Biweight_residual_dis,result_LTS_residual_dis,cex.lab=cex)
abline(lm(result_LTS_residual_dis ~ result_Biweight_residual_dis), col = "red")

